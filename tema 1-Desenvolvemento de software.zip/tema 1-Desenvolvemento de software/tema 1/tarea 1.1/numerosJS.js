// Este codigo ha sido generado por el modulo psexport 20180802-w32 de PSeInt.
// Es posible que el codigo generado no sea completamente correcto. Si encuentra
// errores por favor reportelos en el foro (http://pseint.sourceforge.net).

function sin_titulo() {
	var num1, num2;
	document.write("introduce primer n�mero: ",'<BR/>');
	num1 = prompt();
	document.write("introduce segundo n�mero: ",'<BR/>');
	num2 = prompt();
	if (num1>num2) {
		document.write("el primero es mayor",'<BR/>');
	} else {
		if (num2>num1) {
			document.write("el segundo es mayor",'<BR/>');
		} else {
			document.write("los numeros son iguales!",'<BR/>');
		}
	}
}

