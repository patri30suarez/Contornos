/* Este codigo ha sido generado por el modulo psexport 20180802-w32 de PSeInt.
Es posible que el codigo generado no sea completamente correcto. Si encuentra
errores por favor reportelos en el foro (http://pseint.sourceforge.net). */

#include<stdio.h>

/* Para las variables que no se pudo determinar el tipo se utiliza la constante
   SIN_TIPO. El usuario debe reemplazar sus ocurrencias por el tipo adecuado
   (usualmente int,float,bool, o char[]). */
#define SIN_TIPO float

/* Para leer variables de texto se utiliza scanf, que lee solo una palabra. 
   Para leer una linea completa (es decir, incluyendo los espacios en blanco)
   se debe utilzar ges (ej, reemplazar scanf("%s",x) por gets(x)) pero 
   obliga a agregar un getchar() antes del gets si antes del mismo se ley�
   otra variable con scanf. */

int main() {
	SIN_TIPO num1;
	SIN_TIPO num2;
	printf("introduce primer n�mero: \n");
	scanf("%s",num1);
	printf("introduce segundo n�mero: \n");
	scanf("%s",num2);
	if (num1>num2) {
		printf("el primero es mayor\n");
	} else {
		if (num2>num1) {
			printf("el segundo es mayor\n");
		} else {
			printf("los numeros son iguales!\n");
		}
	}
	return 0;
}

