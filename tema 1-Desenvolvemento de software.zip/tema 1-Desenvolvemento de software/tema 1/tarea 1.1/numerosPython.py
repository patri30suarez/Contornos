# Este codigo ha sido generado por el modulo psexport 20180802-w32 de PSeInt.
# Es posible que el codigo generado no sea completamente correcto. Si encuentra
# errores por favor reportelos en el foro (http://pseint.sourceforge.net).


if __name__ == '__main__':
	print("introduce primer n�mero: ")
	num1 = input()
	print("introduce segundo n�mero: ")
	num2 = input()
	if num1>num2:
		print("el primero es mayor")
	else:
		if num2>num1:
			print("el segundo es mayor")
		else:
			print("los numeros son iguales!")

