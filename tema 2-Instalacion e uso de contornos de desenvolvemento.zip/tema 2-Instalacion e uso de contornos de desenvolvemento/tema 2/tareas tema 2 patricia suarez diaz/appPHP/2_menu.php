﻿<?php include '1_validar_sesion.php'; ?>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Menú principal</title>
    </head>
    <body>
        <h1>Menú principal</h1>
        <a href="./3_verpreguntas.php">Ver preguntas</a><br />
        <a href="./3_anadirpregunta.php">Añadir pregunta</a><br />
        <a href="./3_borrarpregunta.php">Borrar pregunta</a><br />
        <a href="./3_crearexamen.php">Generar examen(PDF)</a><br />
        <a href="./3_desconectar.php">Desconectar</a><br />
    </body>
</html>