<?php include '1_validar_sesion.php';?>
<html>
 <head>
        <meta charset="UTF-8"/>
        <title>Ver preguntas</title>
    </head>
<body>
<h1>Lista de preguntas almacenadas</h1>
<?php
$mysqli = new mysqli('localhost', 'user1', 'pass1', 'practicas');
$mysqli->set_charset("utf8");
$registro = $mysqli->query("SELECT * from PREGUNTAS order by ID");
while($row = $registro->fetch_object()){
    echo "Num pregunta:".$row->ID. "-" . $row->PREGUNTA . "- resp correcta:" . $row->CORRECTA . "<br />";
    echo "(1) ...".$row->RESPUESTA1."<br />";
    echo "(2) ...".$row->RESPUESTA2."<br />";
    echo "(3) ...".$row->RESPUESTA3."<br />";
    echo "..............................<br />";
} 
mysqli_free_result($registro);
mysqli_close($mysqli);  
?>
<br/>
<a href="./2_menu.php">Volver al menú</a><br />
</body>
</html>

