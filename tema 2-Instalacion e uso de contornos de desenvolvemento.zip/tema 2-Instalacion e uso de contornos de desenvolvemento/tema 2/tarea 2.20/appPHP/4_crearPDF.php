<?php
include '1_validar_sesion.php';
include('./fpdf182/fpdf.php');
define('FPDF_FONTPATH','./fpdf182/font/');  

$cantidad=$_POST['cantidad']; 
$tabla = Array();
reset($tabla);  
$mysqli = new mysqli('localhost', 'user1', 'pass1', 'practicas');
$mysqli->set_charset("utf8");
$registro = $mysqli->query("SELECT * from PREGUNTAS order by ID");
$total=0;
while($row = $registro->fetch_object()){
    $tabla[$total][1]=$row->ID;
	$tabla[$total][2]=$row->PREGUNTA;
	$tabla[$total][3]=$row->RESPUESTA1;
	$tabla[$total][4]=$row->RESPUESTA2;
	$tabla[$total][5]=$row->RESPUESTA3;
	$total++;
} 
mysqli_free_result($registro);
mysqli_close($mysqli);  

$MiPDF=new FPDF('P','mm','A4');
$MiPDF->SetDisplayMode('real');
$MiPDF->SetAutoPageBreak(1,8);
$MiPDF->Addpage();
$MiPDF->SetFont('Arial','',11);

if ($cantidad > $total) {
     $MiPDF->Write(10,"No hay preguntas suficientes\n");
}
else {
	  $lista = Array();
	  reset($lista);
	  for($cont=1;$cont<=$cantidad;$cont++) {
		do {
			$rep=0;
			$lista[$cont]=rand(0,$total-1);
				for($bus=1; $bus<$cont; $bus++)   {
				   if($lista[$cont]==$lista[$bus]) {$rep=1;break; }
				}
		} while($rep);
	  }
	  $MiPDF->Write(10,"EXAMEN\n\n");
	  $cont=1;
      foreach($lista as $valor) {
	      $texto=$cont . ": ". $tabla[$valor][2] . " (Pregunta:" . $tabla[$valor][1]. ")\n";
		  $MiPDF->Write(10,$texto);
		  $texto="(a)    ".$tabla[$valor][3]. "\n";
		  $MiPDF->Write(10,$texto);
		  $texto="(b)    ".$tabla[$valor][4]. "\n";
		  $MiPDF->Write(10,$texto);
		  $texto="(c)    ".$tabla[$valor][5]. "\n";
		  $MiPDF->Write(10,$texto);
		  $cont++;
	  }
}
$MiPDF->Output();
?> 

