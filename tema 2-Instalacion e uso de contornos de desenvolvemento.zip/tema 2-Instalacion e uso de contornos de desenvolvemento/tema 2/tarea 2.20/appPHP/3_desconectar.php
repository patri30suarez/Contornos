<?php include '1_validar_sesion.php';?>
<html>
 <head>
        <meta charset="UTF-8"/>
        <title>Desconectar</title>
</head>
<body>
<h1>Hasta pronto!!</h1>
<?php 
unset($_SESSION['pass']);
?>
</body>
</html>