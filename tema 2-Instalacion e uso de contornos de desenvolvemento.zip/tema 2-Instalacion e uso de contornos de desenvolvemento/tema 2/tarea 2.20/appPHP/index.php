<html>
 <head>
        <meta charset="UTF-8"/>
        <title>Inicio</title>
    </head>
<body>
<h1>Gestión de examen tipo test</h1>
<form action="./1_crear_sesion.php" method="post">
Introduzca la clave de acceso<input type="password" name="pass"/><br>
<input type="submit"  value="Entrar" />
</form>
</body>
</html>