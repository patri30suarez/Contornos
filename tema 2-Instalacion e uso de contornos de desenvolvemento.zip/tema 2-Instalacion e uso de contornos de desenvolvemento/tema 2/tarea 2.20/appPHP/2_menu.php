﻿<?php include '1_validar_sesion.php'; ?>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Menú principal</title>
    </head>
    <body>
        
       <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
<a class="navbar-brand" href="#">Menú</a>

<div class="collapse navbar-collapse" id="navbar1">
<div class="navbar-nav">
<a class ="nav-item nav-link active" href="./3_crearexamen.php">Examen PDF</a>
<a class ="nav-item nav-link dropdown-toggle"
data-toggle ="dropdown" href ="#"> Preguntas<span class="caret"></span></a>
<div class="dropdown-menu">
<a class="dropdown-item" href ="./3_verpreguntas.php">Ver</a>
<a class="dropdown-item" href ="./3_anadirpregunta.php"> Añadir</a>
<a class="dropdown-item" href ="./3_borrarpregunta.php">Borrar</a>
</div>
<a class ="nav-item nav-link" href="./3_desconectar.php">Desconectar</a>
<a class ="nav-item nav-link" href="./3_cambiarpass.php">Cambiar Pass</a>
</div>
</div>
</nav>
    </body>
</html>