<?php include '1_validar_sesion.php';?>
<html>
<body>
<?php 
$base="practicas"; 
$pregunta=$_POST['pregunta']; 

$mysqli = new mysqli('localhost', 'user1', 'pass1', 'practicas');
$mysqli->set_charset("utf8");
$registro = $mysqli->query("DELETE FROM PREGUNTAS where ID='$pregunta'");  
if ($registro){   echo "<h1>¡Borrado correcto!</h1>"; }
else{   echo "Error:".mysqli_error($this->mysqli)."  <br />"; 
} 
mysqli_close($mysqli);  
?> 
<a href="./3_borrarpregunta.php">Borrar otra pregunta</a><br />
<a href="./2_menu.php">Volver al menu</a><br />
</body>
</html>   
