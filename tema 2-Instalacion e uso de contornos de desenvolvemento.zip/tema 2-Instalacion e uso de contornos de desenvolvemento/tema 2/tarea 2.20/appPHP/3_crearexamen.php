<?php include '1_validar_sesion.php';?>
<html>
 <head>
        <meta charset="UTF-8"/>
        <title>Crear examen</title>
    </head>
<body>
<h1>Generar examen</h1>
Se generará examen del numero de preguntas deseadas
elegidas al azar entre las preguntas almacenadas<br/>
<form action="./4_crearPDF.php" method="post">
Cantidad de preguntas:<input type="text" name="cantidad"/><br/>
<input type="submit"  value="Generar" />
</form>
</body>
</html>
