<?php include '1_validar_sesion.php'; ?>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Añadir pregunta</title>
    </head>
    <body>
        <h1>Alta de pegunta de examen</h1>
        <form action="./4_BDanadir.php" method="post">
            Texto pregunta<input type="text" name="pregunta"/><br/>
            Respuesta 1<input type="text" name="resp1"/><br/>
            Respuesta 2<input type="text" name="resp2"/><br/>
            Respuesta 3<input type="text" name="resp3"/><br/>
            Respuesta correcta:
            1<input type="radio" value="1" name="correcta" checked="checked"/>
            2<input type="radio" value="2" name="correcta"/>
            3<input type="radio" value="3" name="correcta"/><br/>
            <input type="submit"  value="Dar de alta" />
        </form>
    </body>
</html>
