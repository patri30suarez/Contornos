<?php
session_cache_limiter('nocache,private');
session_start();
$f1=fopen("password.txt","r");
if (!feof($f1)) {
    $pass = fgets($f1);
}
fclose($f1);
if (password_verify ($_SESSION['pass'] , $pass ) == false)
Header ("Location:5_error1.html");
?>