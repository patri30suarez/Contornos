<?php include '1_validar_sesion.php';?>
<html>
<body>
<?php 
$pregunta=$_POST['pregunta']; 
$resp1=$_POST['resp1']; 
$resp2=$_POST['resp2']; 
$resp3=$_POST['resp3']; 
$correcta=$_POST['correcta']; 

$mysqli = new mysqli('localhost', 'user1', 'pass1', 'practicas');
$mysqli->set_charset("utf8");

$registro = $mysqli->query("INSERT preguntas (pregunta,respuesta1,respuesta2,respuesta3,correcta)
             VALUES ('$pregunta','$resp1','$resp2','$resp3','$correcta')");  
if ($registro){   echo "<h1>¡Insercion correcta!</h1>"; }
else{   echo "Error:".mysqli_error($this->mysqli)."  <br />"; 
} 
mysqli_close($mysqli);  
?> 
<a href="./3_anadirpregunta.php">Añadir otra pregunta</a><br />
<a href="./2_menu.php">Volver al menu</a><br />
</body>
</html>   
