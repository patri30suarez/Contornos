<?php
session_cache_limiter('nocache,private');
session_start();
$_SESSION['pass']=$_POST['pass'];
Header ("Location:2_menu.php");
?>