<?php include '1_validar_sesion.php';?>
<html>
 <head>
        <meta charset="UTF-8"/>
        <title>Borrar pregunta</title>
<?php 
  function llenar_preguntas (){	
    $mysqli = new mysqli('localhost', 'user1', 'pass1', 'practicas');
    $mysqli->set_charset("utf8");


    $registro = $mysqli->query("SELECT ID, PREGUNTA from PREGUNTAS order by ID");
	while($row = $registro->fetch_object()){
		echo '<option value="'.$row->ID.'">'.$row->ID."-".$row->PREGUNTA.'</option>';
	}		
	mysqli_free_result($registro);
	mysqli_close($mysqli);  
} 
?>
</head>
<body>
<h1>Borrar pregunta de examen</h1>
<form action="./4_BDborrar.php" method="post">
Seleccione la pregunta a borrar:<br/>
<select name="pregunta" size="5">
<?php llenar_preguntas();?>              		  
</select>
<br/>
<input type="submit"  value="Borrar" />
</form>
</body>
</html>
