CREATE TABLE IF NOT EXISTS `preguntas` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PREGUNTA` varchar(200) NOT NULL,
  `RESPUESTA1` varchar(200) NOT NULL,
  `RESPUESTA2` varchar(200) NOT NULL,
  `RESPUESTA3` varchar(200) NOT NULL,
  `CORRECTA` tinyint(4) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Volcar la base de datos para la tabla `preguntas`
--

INSERT INTO `preguntas` (`ID`, `PREGUNTA`, `RESPUESTA1`, `RESPUESTA2`, `RESPUESTA3`, `CORRECTA`) VALUES
(6, 'Calcula 10 x 7', '70', '77', '107', 1),
(7, 'Calcula 12 / 4', '4', '12', '3', 3),
(8, 'Calcula 7 x 8', '54', '56', '78', 2),
(9, 'Calcula 10 - 12', '0', '-2', '2', 2),
(10, 'Calcula 100 x 100', '1000', '100000', '10000', 3);

