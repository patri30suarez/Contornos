
<?php include '1_validar_sesion.php'; ?>
<html>
    <head>
        <script>
            function validarFormulario() {
                if (document.forms["formu"]["pass1"].value.length < 4 ||
                        document.forms["formu"]["pass2"].value.length < 4) {
                    window.alert("La contraseña debe ser de 4 o mas caracteres");
                    document.forms["formu"]["pass1"].value = "";
                    document.forms["formu"]["pass2"].value = "";
                    document.forms["formu"]["pass1"].focus();
                    return (false);
                }
                if (document.forms["formu"]["pass1"].value !=
                        document.forms["formu"]["pass2"].value) {
                    window.alert("Las contraseñas no coinciden");
                    document.forms["formu"]["pass1"].value = "";
                    document.forms["formu"]["pass2"].value = "";
                    document.forms["formu"]["pass1"].focus();
                    return (false);
                }
                return (true);
            }
        </script>
    </head>
    <body>
        <h1>Cambiar contraseña</h1>
       <form name="formu" action="./4_FileCambiarPass.php"
onsubmit="return (validarFormulario());" method="post">
            Nueva contraseña<input type="password" name="pass1" required/><br/>
            Repetir contraseña<input type="password" name="pass2" required/><br/>
            <input type="submit" value="Cambiar Contraseña" />
        </form>
    </body>