#include <iostream>

int main() {
    std::cout << "Hello from Fenix!" << std::endl;
}